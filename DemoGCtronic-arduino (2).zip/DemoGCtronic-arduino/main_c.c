#include "p30F6014A.h"
#include "stdio.h"
#include "string.h"
#include "math.h"
#include <time.h>
#include <stdlib.h>

#include <motor_led/e_init_port.h>
#include <motor_led/advance_one_timer/e_led.h>
#include <motor_led/advance_one_timer/e_motors.h>
#include <motor_led/advance_one_timer/e_agenda.h>
#include <uart/e_uart_char.h>
#include <a_d/advance_ad_scan/e_ad_conv.h>
#include <a_d/advance_ad_scan/e_prox.h>
#include <a_d/advance_ad_scan/e_acc.h>
#include <a_d/advance_ad_scan/e_micro.h>
#include <bluetooth/e_bluetooth.h>
#include <motor_led/e_epuck_ports.h>
#include <acc_gyro/e_lsm330.h>
#include <utility/utility.h>
#include "memory.h"
#include <I2C/e_I2C_protocol.h>

int main() {
    
    char buffer[BUFFER_SIZE];
    unsigned char command = 0;
    unsigned char ledState = 0;
    
    //system initialization
    e_init_port();    // configure port pins
    e_start_agendas_processing();
    e_init_motors();
    e_init_uart1();   // initialize UART to 115200 Kbaud
    e_init_uart2(BAUD115200);   // initialize UART to 115200 Kbaud
    e_init_ad_scan(ALL_ADC);
    
    //Reset if Power on (some problem for few robots)
    if (RCONbits.POR) {
        RCONbits.POR=0;
        __asm__ volatile ("reset");
    }

    resetTime();

    e_i2cp_enable();

    while (1) {

        switch(ledState) {
            case 0: // All leds off.
                LED0 = 0;
                LED1 = 0;
                LED2 = 0;
                LED3 = 0;
                break;
                
            case 1:
                LED0 = 1;
                LED1 = 0;
                LED2 = 0;
                LED3 = 0;
                break;

            case 2:
                LED0 = 0;
                LED1 = 1;
                LED2 = 0;
                LED3 = 0;
                break;

            case 3:
                LED0 = 0;
                LED1 = 0;
                LED2 = 1;
                LED3 = 0;
                break;

            case 4:
                LED0 = 0;
                LED1 = 0;
                LED2 = 0;
                LED3 = 1;
                break;
        }

        command = e_i2cp_read(0x0E, 0x02);
        switch(command) {
            case 0: // Stop the robot.
                ledState = 0;
                e_set_speed_left(0);
                e_set_speed_right(0);
                break;
            case 1: // Rotate left.
                e_set_speed_left(-200);
                e_set_speed_right(200);
                ledState = 1;
                break;
            case 2: // Rotate right.
                e_set_speed_left(200);
                e_set_speed_right(-200);
                ledState = 2;
                break;
            case 3: // Forward.
                e_set_speed_left(300);
                e_set_speed_right(300);
                ledState = 3;
                break;
            case 4: // Backward.
                e_set_speed_left(-300);
                e_set_speed_right(-300);
                ledState = 4;
                break;
        }

        //sprintf(buffer, "%d\r\n", command);
        //e_send_uart1_char(buffer, strlen(buffer));
        //while(e_uart1_sending());

        while(getDiffTimeMs() <= 100);   // Wait 100 ms.
        resetTime();
    }

    e_i2cp_disable();

    return 0;

}

