
void wait(long num);
int getselector();
unsigned int getBatteryValueRaw();
unsigned int getBatteryValuePercentage();
void resetTime(void);
float getDiffTimeMs(void);
float getDiffTimeMsAndReset(void);
