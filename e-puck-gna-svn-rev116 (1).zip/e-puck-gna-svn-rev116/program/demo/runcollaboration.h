
int run_collaboration(void);
