function [ranges] = getRangefinderData( ePic)
%     
% data = zeros(1,16);
%%
ranges = zeros(1,16,'uint8');
flush(ePic);
write(ePic,'W,14,0,82')
pause(0.2)

%flushing after state change
flush(ePic);
write(ePic,'Y,14,0')
a = read(ePic) %'Y,#,#'
a = read(ePic) %'Y,#'
%%
d1=0;
d2=0;
fprintf('returned data :\n')
for i=1:16
flush(ePic);
write(ePic,'Y,14,0');
a = read(ePic); %'Y,#,#'
%fprintf('sent command %s\n',a)
%class(a)

a = read(ePic)
% fprintf('Data: %s\n', a);
% fprintf('Split Data: \n');
% b=strsplit(a,',');
% disp(b);
% fprintf('Casted Data: \n');
% bVal = uint8(str2num(b{2}))
% 
% ranges(i) = bVal;
% 
% 
% % a = a{2}
% 
% % a=a+127;
% 
% % if mod(i,2)==0
% %     d1=str2num(a);
% % else
% %     d2=str2num(a);
% % end
% 
% % if mod(i,2)==0
% %     ranges(floor(i/2)) = d1+d2*2^8
% % end

pause(0.2)


end

%% Test I2C Read
flush(ePic);
write(ePic,'Y,14,0')
a = read(ePic);
a = [a read(ePic)]
%%
    flush(ePic);
    write(ePic,'Y,14,0'); %send a read I2C to epuck, this will prompt arduino for information
    bit = read(ePic); %sent command repeat
    bit = read(ePic)%'y,###
    ranges = [ranges bit];


bit = strsplit(bit,',');
bit = bit{2};
bit = str2double(bit)

ranges = [ranges bit];

end